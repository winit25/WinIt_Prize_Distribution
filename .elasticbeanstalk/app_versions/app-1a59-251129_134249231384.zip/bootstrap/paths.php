<?php

/**
 * Override Laravel's path resolution to ensure correct paths on AWS EB
 * This file ensures base_path() resolves correctly on the server
 */

// Detect if we're on AWS Elastic Beanstalk
if (is_dir('/var/app/current')) {
    // Override base_path() resolution
    if (!function_exists('base_path_override')) {
        function base_path_override($path = '') {
            $base = '/var/app/current';
            return $base . ($path ? DIRECTORY_SEPARATOR . ltrim($path, DIRECTORY_SEPARATOR) : $path);
        }
    }
}

