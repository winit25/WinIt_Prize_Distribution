<img src="{{ asset('images/winit-logo-C73aMBts (2).svg') }}" alt="WinIt Logo" {{ $attributes->merge(['class' => 'h-auto']) }} style="max-width: 100%; height: auto;">
