<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Tawk.to Live Chat Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration for Tawk.to live chat widget integration
    |
    */

    'enabled' => env('TAWK_ENABLED', false),

    'property_id' => env('TAWK_PROPERTY_ID', '691b089cdde8a31959180b3a'),

    'widget_id' => env('TAWK_WIDGET_ID', '1ja8pj9c5'),

];

