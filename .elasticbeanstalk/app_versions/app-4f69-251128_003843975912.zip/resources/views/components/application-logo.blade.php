<img src="{{ asset('images/winit-logo.png') }}" alt="WinIt Logo" {{ $attributes->merge(['class' => 'h-auto']) }} style="max-width: 100%; height: auto;">
