<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\BuyPowerServiceProvider::class,
];
